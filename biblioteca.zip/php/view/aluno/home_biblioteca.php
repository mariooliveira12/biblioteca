
<html>
    <div class="container-fluid">
        <div class="row">
            <div class="col-4">
            <div class="card" style="width: 18rem;">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              </div>
              <ul class="list-group list-group-flush">
                <li class="list-group-item">Titulo</li>
                <li class="list-group-item">Numero de Cópias</li>
                <li class="list-group-item">Autor</li>
                <li class="list-group-item">Estado do Livro</li>
                <li class="list-group-item">Condição do Livro</li>
              </ul>
              <div class="card-body">
                <a href="emprestimo.php?emprestimo_livro"><button tupe="button" class="btn btn-success">Emprestimo</button></a>
                <a href="reserva.php?reserva_livro" class="text-white"><button tupe="button" class="btn btn-primary">Reservar</button></a>
              </div>
            </div>
            </div>
            <div class="col-4">
            <div class="card" style="width: 18rem;">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              </div>
              <ul class="list-group list-group-flush">
                <li class="list-group-item">Titulo</li>
                <li class="list-group-item">Numero de Cópias</li>
                <li class="list-group-item">Autor</li>
                <li class="list-group-item">Estado do Livro</li>
                <li class="list-group-item">Condição do Livro</li>
              </ul>
              <div class="card-body">
                <a href="emprestimo.php?emprestimo_livro"><button tupe="button" class="btn btn-success">Emprestimo</button></a>
                <a href="reserva.php?reserva_livro" class="text-white"><button tupe="button" class="btn btn-primary">Reservar</button></a>
              </div>
            </div>
            </div>
            <div class="col-4">
            <div class="card" style="width: 18rem;">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              </div>
              <ul class="list-group list-group-flush">
                <li class="list-group-item">Titulo</li>
                <li class="list-group-item">Numero de Cópias</li>
                <li class="list-group-item">Autor</li>
                <li class="list-group-item">Estado do Livro</li>
                <li class="list-group-item">Condição do Livro</li>
              </ul>
              <div class="card-body">
                <a href="emprestimo.php?emprestimo_livro"><button tupe="button" class="btn btn-success">Emprestimo</button></a>
                <a href="reserva.php?reserva_livro" class="text-white"><button tupe="button" class="btn btn-primary">Reservar</button></a>
              </div>
            </div>
            </div>
            <div class="col-4">
            <div class="card" style="width: 18rem; margin-top: 4rem;">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              </div>
              <ul class="list-group list-group-flush">
                <li class="list-group-item">Titulo</li>
                <li class="list-group-item">Numero de Cópias</li>
                <li class="list-group-item">Autor</li>
                <li class="list-group-item">Estado do Livro</li>
                <li class="list-group-item">Condição do Livro</li>
              </ul>
              <div class="card-body">
                <a href="emprestimo.php?emprestimo_livro"><button type="button" class="btn btn-success">Emprestimo</button></a>
                <a href="reserva.php?reserva_livro" class="text-white"><button type="button" class="btn btn-primary">Reservar</button></a>
              </div>
            </div>
            </div>
            <div class="col-4">
            <div class="card" style="width: 18rem; margin-top: 4rem;">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              </div>
              <ul class="list-group list-group-flush">
                <li class="list-group-item">Titulo</li>
                <li class="list-group-item">Numero de Cópias</li>
                <li class="list-group-item">Autor</li>
                <li class="list-group-item">Estado do Livro</li>
                <li class="list-group-item">Condição do Livro</li>
              </ul>
              <div class="card-body">
                <a href="emprestimo.php?emprestimo_livro"><button type="button" class="btn btn-success">Emprestimo</button></a>
                <a href="#" class="text-white"><button type="button" class="btn btn-primary">Reservar</button></a>
              </div>
            </div>
            </div>
            <div class="col-4">
            <div class="card" style="width: 18rem; margin-top: 4rem;">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              </div>
              <ul class="list-group list-group-flush">
                <li class="list-group-item">Titulo</li>
                <li class="list-group-item">Numero de Cópias</li>
                <li class="list-group-item">Autor</li>
                <li class="list-group-item">Estado do Livro</li>
                <li class="list-group-item">Condição do Livro</li>
              </ul>
              <div class="card-body">
                <a href="emprestimo.php?emprestimo_livro"><button type="submit" class="btn btn-success">Emprestimo</button></a>
                <a href="reserva.php?reserva_livro" class="text-white"><button type="button" class="btn btn-primary">Reservar</button></a>
              </div>
            </div>
            </div>
        </div>
    </div>
</html>